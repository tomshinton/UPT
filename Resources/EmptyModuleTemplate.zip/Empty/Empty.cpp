#include <Runtime/Core/Public/Modules/ModuleManager.h>
 
class FEmpty : public IModuleInterface
{
	virtual void StartupModule() override { }
	virtual void ShutdownModule() override { }
};

IMPLEMENT_MODULE(FEmpty, Empty)